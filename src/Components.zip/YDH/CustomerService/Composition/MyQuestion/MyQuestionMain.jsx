import React from 'react';

function MyQuestionMain(props) {
    return (
        <div>
            내 문의 메인페이지.
        </div>
    );
}

export default MyQuestionMain;