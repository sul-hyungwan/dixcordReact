import React from 'react';
import ServiceSearch from '../../ServiceSearch';

function QnAMain(props) {
    return (
        <div>
            <ServiceSearch/>
            자주 묻는 질문 메인페이지.
        </div>
    );
}

export default QnAMain;