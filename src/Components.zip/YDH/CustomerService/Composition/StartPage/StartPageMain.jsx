import React from 'react';

function StartPageMain(props) {
    return (
        <div>
            시작하기 페이지 메인페이지.
        </div>
    );
}

export default StartPageMain;