import React from 'react';

function CustomerServiceSearch(props) {
    return (
        <div>
            <h1>무엇을 도와드릴까요?</h1><br/>
            도움이 필요하신가요? 저희가 도와드리겠습니다<br/>
            <input type="text" name="search" id="search" value="검색"/>
        </div>
    );
}

export default CustomerServiceSearch;