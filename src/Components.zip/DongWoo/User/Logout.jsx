import React, { useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Logout({status}) {

    const nav = useNavigate();

    axios.post('/test/api/logout')
        .then(response => {
            console.log(response.data);
            status(false);
            nav('/');
        })
        .catch(err => console.log(err));

    return (
        <div>
            
        </div>
    );
}

export default Logout;