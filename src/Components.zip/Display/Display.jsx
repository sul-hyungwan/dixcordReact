import React, { useState, useEffect } from 'react';
import { styled } from 'styled-components';
import Login from '../Login/Login';
import MainHome from '../Layout/MainHome';
import { Route, Routes } from 'react-router-dom';
import Header from '../Layout/Header';
import Main from '../Layout/Main';
import Logout from '../DongWoo/User/Logout';
import Register from '../DongWoo/User/Register';
import axios from 'axios';
import SideBarLeftArea from '../ChatRoom/SideBarLeftArea';
import SideBarRightArea from '../ChatRoom/SideBarRightArea';
import ChatRoom from '../ChatRoom/ChatRoom';
import Friend from '../Seoyeon/Friend/Friend';
import CustomerService from '../YDH/CustomerService/CustomerService';
import NoticeMain from '../YDH/CustomerService/Composition/Notice/NoticeMain';
import QnAMain from '../YDH/CustomerService/Composition/QnA/QnAMain';
import StartPageMain from '../YDH/CustomerService/Composition/StartPage/StartPageMain';
import MyQuestionMain from '../YDH/CustomerService/Composition/MyQuestion/MyQuestionMain';
import NoticeDetail from '../YDH/CustomerService/Composition/Notice/NoticeDetail';
import NoticeModify from '../YDH/CustomerService/Composition/Notice/NoticeModify';
import NoticeWrite from '../YDH/CustomerService/Composition/Notice/NoticeWrite';
import Test from '../Hoyeon/Test';

const Container = styled.div`
    display: flex;
    flex-direction: column;
    height: 900px;
    width: 100%;
    box-sizing: border-box;
    display: inline-block;
    overflow: hidden;
`;

const HeaderArea = styled.div`
    height: 10%; /* 헤더 영역 */
    box-sizing: border-box;
`;

const BodyArea = styled.div`
    display: flex; /* 가로로 나열 */
    flex-direction: row;
    height: 90%; /* BodyArea의 높이를 전체의 90%로 설정 */
    width: 100%;
    box-sizing: border-box;
`;
const SideBarDiv = styled.div`
    display: flex;
    flex-direction: row;
`;

const MainContentDiv = styled.div`
    flex-grow: 1;
`;

function Display(props) {

    const [getUser, setUser] = useState(null);

    const [loginStatus, setLoginStatus] = useState(false);

    const [sideBarStatus, setSideBarStatus] = useState('friend');

    const [chatRoomStatus, setChatRoomStatus] = useState();

    const loginUser = async () => {
        await axios.get('/test/api/user')
            .then(response => {
                if(response.data.principal.member === undefined){
                    setUser(null);
                    return;
                }
                setUser(response.data.principal.member);
            });
    }

    useEffect(() => {
        loginUser();
    }, [loginStatus]);
    

    return (
        <>
            { getUser === null ? 
            <>
                <HeaderArea>
                    <Header data={getUser}/>
                </HeaderArea>
                <>
                    <Routes>
                        <Route path='/' element={<MainHome/>}/>
                        <Route path='/login' element={<Login data={setUser} status={setLoginStatus}/>}/>
                        <Route path='/register' element={<Register/>}/>
                        <Route path='/service' element={<CustomerService/>}/>
                        <Route path='/service/qna' element={<QnAMain/>}/>
                        <Route path='/service/notice' element={<NoticeMain/>}/>
                        <Route path='/service/notice/:idx' element={<NoticeDetail/>}/>
                        <Route path='/service/startpage' element={<StartPageMain/>}/>
                    </Routes>
                </>
            </>
            : 
            <Container>
                <HeaderArea>
                    <Header data={getUser}/>
                </HeaderArea>
                <BodyArea>
                    <SideBarDiv>
                        <SideBarLeftArea data={getUser} rightSide={setSideBarStatus} roomStatus={setChatRoomStatus}/>
                        <SideBarRightArea sideStatus={sideBarStatus}></SideBarRightArea>
                    </SideBarDiv>
                    <MainContentDiv>
                        <Routes>
                            <Route path='/' element={<Main/>}/>
                            <Route path="/friend" element={<Friend userData={getUser}/>} />
                            <Route path='/room/:pId' element={<ChatRoom/>}/>
                            <Route path='/logout' element={<Logout status={setLoginStatus}/>}/>
                            <Route path='/service' element={<CustomerService/>}/>
                            <Route path='/service/qna' element={<QnAMain/>}/>
                            <Route path='/service/notice' element={<NoticeMain/>}/>
                            <Route path='/service/notice/:idx' element={<NoticeDetail/>}/>
                            <Route path='/service/startpage' element={<StartPageMain/>}/>
                            <Route path='/service/myquestion' element={<MyQuestionMain/>}/>
                            <Route path='/service/notice/write' element={<NoticeWrite/>}/> {/* 관리자 전용 */}
                            <Route path='/service/notice/modify/:idx' element={<NoticeModify/>}/>
                            <Route path='/chat' element={<Test user={getUser}/>}/>
                        </Routes>
                    </MainContentDiv>
                </BodyArea>
            </Container>
            }
        </>
    );
}

export default Display;